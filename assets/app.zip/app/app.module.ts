import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router'
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import {MatInputModule, MatFormFieldModule} from '@angular/material';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { AngularFireModule } from 'angularfire2';
import { AngularFirestoreModule } from 'angularfire2/firestore';
import { AngularFireAuthModule } from 'angularfire2/auth';
import { environment } from '../environments/environment';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { AuthService } from './shared/services/auth.service';
export const _Routes: Routes =
  [
    {path: "login",component:LoginComponent}
  ]
@NgModule({
  declarations: 
  [
    AppComponent,
    LoginComponent
  ],
  imports: [
  
    BrowserModule, RouterModule.forRoot(_Routes),
     /* BrowserAnimationsModule,MatInputModule,MatFormFieldModule,
  AngularFireModule,AngularFirestoreModule,AngularFireAuthModule,AngularFireModule.initializeApp(environment.firebase)*/
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
