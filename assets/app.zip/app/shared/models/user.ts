export class Login
{
    Username:string;
    Password:string;
}
export class Register
{
    Username:string;
    Password:string;
    Fullname:string;
    Role:string;
    Email:string;
    Phonenumber:string;
}
export class Profile
{
    Username:string;
    Password:string;
    Fullname:string;
    Role:string;
    Email:string;
    Phonenumber:string;
}