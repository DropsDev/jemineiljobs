import { Component, OnInit } from '@angular/core';
import { AuthService } from '../shared/services/auth.service';
declare var $;
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit { 
  ngOnInit() {
    $("body").addClass("auth-page")
  }
/*  errorMessage:string="";  successMessage:string="";
  constructor(private authService:AuthService) {
    alert(0)
   }

 
  ngOnDestroy(){
    $("body").removeClass("auth-page")
  }
  tryRegister(value){
    this.authService.doRegister(value)
    .then(res => {
      console.log(res);
      this.errorMessage = "";
      this.successMessage = "Your account has been created";
    }, err => {
      console.log(err);
      this.errorMessage = err.message;
      this.successMessage = "";
    })
  }*/
}
